"""**LLM bash** is a chain that uses LLM to interpret a prompt and
executes **bash** code."""
